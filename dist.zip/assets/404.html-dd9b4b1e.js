import{_ as e,V as t,W as _}from"./framework-c954d91f.js";const c={};function r(n,o){return t(),_("div")}const a=e(c,[["render",r],["__file","404.html.vue"]]);export{a as default};
